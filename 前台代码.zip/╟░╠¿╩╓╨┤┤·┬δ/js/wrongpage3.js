
$(document).ready(function(){
	$("#bum").click(function(){
		
			$("#r32").css("display","block");
			$("#jumpx").css("display","none");
	})
	$(".s2").click(function(){
		
			$("#r32").css("display","block");
			$("#jumpx").css("display","none");
	})
	$("#r33").click(function(){
		    $("#r32").css("display","none");
		    $("#jumpx").css("display","block");
	})

})