var id=document.getElementById("button").value;
if(id != 0||id != null){
	function display()
	{
		var login =document.getElementsByName("login");
		login.style.display="none";
		var aftlog = document.getElementsByName("after_login");
		aftlog.style.display="bolock";
	}

}